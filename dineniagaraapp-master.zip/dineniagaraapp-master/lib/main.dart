import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:geolocator/geolocator.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Dine Niagara',
      theme: ThemeData(
        primarySwatch: Colors.deepOrange,
      ),
      home: MyHomePage(key: Key('din_niagara'), title: 'Dine Niagara'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({required Key key, required this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  late InAppWebViewController webView;
  String _rootUrl = 'https://dineniagara.ca/';
  String _initialUrl = "";
  String url = "";
  double progress = 0;
  Position _currentPosition = Position(
      latitude: 0.00,
      longitude: 0.00,
      timestamp: DateTime.now(),
      accuracy: 0,
      speedAccuracy: 0,
      speed: 0,
      altitude: 0,
      heading: 0);
  bool _isLocationsPage = true;
  bool _isBackVisible = false;
  bool _loadLocation = false;
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();

    _getLocation().then((position) {
      setState(() {
        _currentPosition = position;
      });
    });

    setState(() {
      _initialUrl = _rootUrl + 'locations?sort_by=distance&pageLimit=100';
    });
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future<Position> _getLocation() async {
    var currentLocation;
    try {
      currentLocation = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.best);
    } catch (e) {
      currentLocation = null;
    }
    return currentLocation;
  }

  Future<bool> _onBack() async {
    bool goBack = true;
    var value = await webView.canGoBack();
    if (value) {
      webView.goBack();
      return false;
    } else {
      await showDialog(
          context: context,
          builder: (context) => new AlertDialog(
                  title: new Text('Confirmation'),
                  content: new Text('Do you want to exit the app?'),
                  actions: <Widget>[
                    new TextButton(
                      onPressed: () {
                        Navigator.of(context).pop(false);
                        setState(() {
                          goBack = false;
                        });
                      },
                      child: new Text('No'),
                    ),
                    new TextButton(
                      onPressed: () {
                        Navigator.of(context).pop();
                        setState(() {
                          goBack = true;
                        });
                      },
                      child: new Text('Yes'),
                    )
                  ]));

      if (goBack) Navigator.pop(context);
      return goBack;
    }
  }

  bool isLocationsPage() {
    return this.url.contains('locations');
  }

  bool showBackButton() {
    if (isLocationsPage()) {
      return false;
    }
    return true;
  }

  void onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });

    switch (index) {
      case 0: // Order
        {
          setState(() {
            this.url = _initialUrl + "&locationFilter=orderingAvailable";
          });

          webView.loadUrl(urlRequest: URLRequest(url: Uri.parse(this.url)));
        }
        break;

      case 1:
        {
          setState(() {
            this.url = _initialUrl + "&locationFilter=patio";
          });
          webView.loadUrl(urlRequest: URLRequest(url: Uri.parse(this.url)));
        }
        break;

      case 2:
        {
          setState(() {
            this.url = _rootUrl + 'account/orders';
          });
          webView.loadUrl(urlRequest: URLRequest(url: Uri.parse(this.url)));
        }
        break;

      case 3:
        {
          setState(() {
            this.url = _rootUrl + 'account';
          });
          webView.loadUrl(urlRequest: URLRequest(url: Uri.parse(this.url)));
        }
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_currentPosition.latitude != 0.00 &&
        _currentPosition.longitude != 0.00) {
      _initialUrl += '&lat=' +
          _currentPosition.latitude.toString() +
          '&long=' +
          _currentPosition.longitude.toString();
    }

    return WillPopScope(
      onWillPop: _onBack,
      child: Scaffold(
          appBar: AppBar(
              centerTitle: true,
              title: Image.asset(
                'assets/images/dineniagaralogo_white.png',
                fit: BoxFit.contain,
                height: 32,
              ),
              leading: Visibility(
                  visible: _isBackVisible,
                  child: IconButton(
                      icon: Icon(Icons.arrow_back),
                      onPressed: () {
                        webView.goBack();
                      })),
              actions: <Widget>[
                Padding(
                    padding: EdgeInsets.only(right: 20),
                    child: Visibility(
                        visible: _isLocationsPage,
                        child: GestureDetector(
                          onTap: () {
                            _loadLocation = true;
                            _getLocation().then((position) {
                              setState(() {
                                _currentPosition = position;
                              });
                              setState(() {
                                this.url = _initialUrl +
                                    '&lat=' +
                                    _currentPosition.latitude.toString() +
                                    '&lng=' +
                                    _currentPosition.longitude.toString();
                              });
                              _loadLocation = false;
                              webView.loadUrl(
                                  urlRequest:
                                      URLRequest(url: Uri.parse(this.url)));
                            });
                          },
                          child: _loadLocation
                              ? CircularProgressIndicator()
                              : Icon(Icons.near_me),
                        )))
              ]),
          body: InAppWebView(
            // Home Page
            initialUrlRequest: URLRequest(
                url: Uri.parse(
                    _initialUrl + "&locationFilter=orderingAvailable")),
            initialOptions: InAppWebViewGroupOptions(
                crossPlatform: InAppWebViewOptions(
                  useShouldOverrideUrlLoading: true,
                  javaScriptEnabled: true,
                  supportZoom: false,
                  userAgent: "DineNiagaraApp",
                ),
                ios: IOSInAppWebViewOptions(
                  disallowOverScroll: true,
                )),
            onWebViewCreated: (InAppWebViewController controller) {
              webView = controller;
              print("onWebViewCreated");
            },
            onLoadStart: (InAppWebViewController controller, url) {
              setState(() {
                this.url = url.toString();
              });

              setState(() {
                this._isLocationsPage = isLocationsPage();
              });

              setState(() {
                this._isBackVisible = showBackButton();
              });

              if (this.url.contains('account')) {
                setState(() {
                  _currentIndex = 2;
                });
              } else if (this.url.endsWith('login')) {
                setState(() {
                  _currentIndex = 2;
                });
              } else if (this.url.contains('Filter=patio')) {
                setState(() {
                  _currentIndex = 1;
                });
              } else {
                setState(() {
                  _currentIndex = 0;
                });
              }
            },
            shouldOverrideUrlLoading: (controller, navigationAction) async {
              var uri = navigationAction.request.url!;

              if (![
                "http",
                "https",
                "file",
                "chrome",
                "data",
                "javascript",
                "about"
              ].contains(uri.scheme)) {
                if (await canLaunch(url)) {
                  // Launch the App
                  await launch(
                    url,
                  );
                  // and cancel the request
                  return NavigationActionPolicy.CANCEL;
                }
              }

              return NavigationActionPolicy.ALLOW;
            },
            onLoadStop: (InAppWebViewController controller, url) async {
              setState(() {
                this.url = url.toString();
              });
            },
            onProgressChanged:
                (InAppWebViewController controller, int progress) {
              setState(() {
                this.progress = progress / 100;
              });
            },
            onUpdateVisitedHistory:
                (InAppWebViewController controller, url, androidIsReload) {
              setState(() {
                this.url = url.toString();
              });
            },
            onConsoleMessage: (controller, consoleMessage) {
              print(consoleMessage);
            },
          ),
          bottomNavigationBar: BottomNavigationBar(
              onTap: onTabTapped,
              currentIndex: _currentIndex,
              type: BottomNavigationBarType.fixed,
              items: const <BottomNavigationBarItem>[
                BottomNavigationBarItem(
                  icon: Icon(Icons.delivery_dining),
                  label: 'Order',
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.local_dining),
                  label: 'Patios',
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.person),
                  label: 'My Account',
                )
              ])),
    );
  }
}
